slapnet
=======

Safety and Liveness Analysis of Petri Nets with SMT solvers
