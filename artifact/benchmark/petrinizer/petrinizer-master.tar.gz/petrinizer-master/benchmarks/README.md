=====
Description of directories
=====

* ./benchmarks/given-by-daniel-kroening/
  * Set corresponding to CProver. CProver uses BFC.
  * Taken from: http://www.mpi-sws.org/~jkloos/iic-experiments/cprover.zip

* ./benchmarks/ic3-soter/
  * Set corresponding to Soter. Soter uses BFC.
  * The examples correspond to Erlang code
  * See: http://mjolnir.cs.ox.ac.uk/soter/, http://mjolnir.cs.ox.ac.uk/soter/doc/papers.html